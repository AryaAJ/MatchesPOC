package com.example.shadipoc.data

data class Coordinates(
    val latitude: String,
    val longitude: String
)