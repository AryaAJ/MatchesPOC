package com.example.shadipoc.data

data class Dob(
    val age: Int,
    val date: String
)