package com.example.shadipoc.data

data class Timezone(
    val description: String,
    val offset: String
)