package com.example.shadipoc.data

data class MainData(
    val info: Info,
    val results: List<Result>
)