package com.example.shadipoc.data

data class Registered(
    val age: Int,
    val date: String
)