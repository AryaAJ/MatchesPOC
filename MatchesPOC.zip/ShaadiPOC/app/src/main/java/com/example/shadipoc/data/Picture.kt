package com.example.shadipoc.data

data class Picture(
    val large: String,
    val medium: String,
    val thumbnail: String
)