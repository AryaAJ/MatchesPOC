package com.example.shadipoc.data

data class Id(
    val name: String,
    val value: String
)