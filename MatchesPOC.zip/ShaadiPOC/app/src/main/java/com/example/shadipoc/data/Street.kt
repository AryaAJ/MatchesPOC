package com.example.shadipoc.data

data class Street(
    val name: String,
    val number: Int
)