package com.example.shadipoc.room.data

data class User(var email: String, var password: String)